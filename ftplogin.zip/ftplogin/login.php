<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Credenciais do FTP
    $ftp_server = "127.0.0.1"; // Altere para o IP do seu servidor
    $ftp_user = $_POST['username'];
    $ftp_password = $_POST['password'];

    // Testa conexão FTP
    $conn_id = ftp_connect($ftp_server);
    if ($conn_id && @ftp_login($conn_id, $ftp_user, $ftp_password)) {
        // Login bem-sucedido
        $_SESSION['ftp_user'] = $ftp_user;
        $_SESSION['ftp_password'] = $ftp_password;
        ftp_close($conn_id);
        header('Location: ftp_manager.php');
        exit();
    } else {
        $error = "Usuário ou senha inválidos!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login FTP</title>
</head>
<body>
    <h2>Login FTP</h2>
    <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
    <form method="POST">
        <label>Usuário:</label>
        <input type="text" name="username" required><br><br>
        <label>Senha:</label>
        <input type="password" name="password" required><br><br>
        <button type="submit">Entrar</button>
    </form>
</body>
</html>
