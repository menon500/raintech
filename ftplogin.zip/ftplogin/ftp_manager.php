<?php
session_start();

// Verifica se o usuário está autenticado
if (!isset($_SESSION['ftp_user']) || !isset($_SESSION['ftp_password'])) {
    header('Location: login.php');
    exit();
}

// Conecta ao FTP
$ftp_server = "127.0.0.1"; // Altere para o IP do seu servidor
$ftp_user = $_SESSION['ftp_user'];
$ftp_password = $_SESSION['ftp_password'];

$conn_id = ftp_connect($ftp_server);
if (!$conn_id || !ftp_login($conn_id, $ftp_user, $ftp_password)) {
    die("Erro ao conectar ao FTP!");
}

// Upload de arquivos
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $file = $_FILES['file'];
    $upload = ftp_put($conn_id, $file['name'], $file['tmp_name'], FTP_BINARY);
    $message = $upload ? "Arquivo enviado com sucesso!" : "Erro ao enviar o arquivo!";
}

// Exclusão de arquivos
if (isset($_GET['delete'])) {
    $file_to_delete = $_GET['delete'];
    $delete = ftp_delete($conn_id, $file_to_delete);
    $message = $delete ? "Arquivo excluído com sucesso!" : "Erro ao excluir o arquivo!";
}

// Listagem de arquivos
$files = ftp_nlist($conn_id, ".");
ftp_close($conn_id);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Gerenciador FTP</title>
</head>
<body>
    <h2>Gerenciador FTP</h2>
    <?php if (isset($message)) echo "<p>$message</p>"; ?>

    <h3>Enviar Arquivo</h3>
    <form method="POST" enctype="multipart/form-data">
        <input type="file" name="file" required>
        <button type="submit">Enviar</button>
    </form>

    <h3>Arquivos no FTP</h3>
    <ul>
        <?php foreach ($files as $file): ?>
            <li>
                <?php echo $file; ?>
                <a href="ftp_manager.php?delete=<?php echo urlencode($file); ?>">Excluir</a>
            </li>
        <?php endforeach; ?>
    </ul>
</body>
</html>
